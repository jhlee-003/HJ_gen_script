#!/bin/bash
pwg_pid=$1

if [ -z "$pwg_pid" ]; then
    echo "No running pwhg_main process found."
    exit 1
fi

gdb -q -nx -batch \
    -iex "set sysroot /proc/$pwg_pid/root" \
    -ex "set pagination off" \
    -ex "thread apply all bt 20" \
    -ex "detach" \
    -p "$pwg_pid"
